
use master
go
exec chk_wrapper_mssql_health
go
exit

