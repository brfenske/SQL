CREATE proc [dbo].[chk_wrapper_mssql_health] 
as 
begin
  set nocount on
  execute dbo.chk_cpu_busy
  execute dbo.chk_Db_Health_mssql
  execute dbo.chk_disks_free_space
  execute dbo.chk_mssql_error_log
  execute dbo.chk_network_errors
  execute dbo.chk_tot_serv_cache_hit_ratio
  execute dbo.chk_backup_db_status  
  execute dbo.chk_num_connections  

end
