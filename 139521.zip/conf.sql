CREATE TABLE [dbo].[configuration](
	[threshold_value] [decimal](10, 3) NULL,
	[threshold_category] [varchar](30) NULL,
	[compare_op] [char](1) NULL
) ON [PRIMARY]
END
Insert into  configuration (  threshold_value , threshold_category ,compare_op) values ( 100.0, 'DISK_SPACE','<')
Insert into  configuration (  threshold_value , threshold_category, compare_op) values ( 90.0,  'HIT_RATIO','<')
Insert into  configuration (  threshold_value , threshold_category, compare_op) values ( 0,  'NET_ERRORS','>')
Insert into  configuration (  threshold_value , threshold_category, compare_op) values ( 999999,  'CPU_BUSY','>')
Insert into  configuration (  threshold_value , threshold_category, compare_op) values (7,  'BACKUP_DAYS','>')
Insert into  configuration (  threshold_value , threshold_category, compare_op) values ( 2000,  '#CONNECTIONS','>')
go
